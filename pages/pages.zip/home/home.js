//index.js
//获取应用实例
const app = getApp()
console.log(app.globalData)
var BmobSocketIo = require('../../utils/bmobSocketIo.js').BmobSocketIo;
var Bmob = require('../../utils/bmob.js');
var Diary = Bmob.Object.extend("diary");
var uuid=require('../../utils/uuid.modified.js');
Page({
  data: {
    motto: 'Hello wx',  
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    query:{},
    pos:"请选择位置>",
    showView:true,
    uhide:0
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function (query) {
    this.data.query = query;
    this.setData(this.data);
    showView: (query.showView == "true" ? true : false);
   // BmobSocketIo.init();
    var data = {
      "datas": [
        {
          "id": 1,
          "imgurl": "../image/car.png",
          "useDate": "2017-12-22",
          "cx": "奇瑞EQ1",
          "time": "1小时",
          "feiyong": "20元"
        },
        {
          "id": 2,
          "imgurl": "../image/car.png",
          "useDate": "2017-12-22",
          "cx": "奇瑞EQ1",
          "time": "1小时",
          "feiyong": "20元"
        },
        {
          "id": 3,
          "imgurl": "../image/car.png",
          "useDate": "2017-12-22",
          "cx": "奇瑞EQ1",
          "time": "1小时",
          "feiyong": "20元"
        },
        {
          "id": 4,
          "imgurl": "../image/car.png",
          "useDate": "2017-12-22",
          "cx": "奇瑞EQ1",
          "time": "1小时",
          "feiyong": "20元"
        }
      ]
    };
    this.setData({
      carInfoData: data.datas
    })
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  onChangeShowState: function () {
    var that = this;
    that.setData({
      showView: (!that.data.showView)
    })
  },  
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  toggleBtn: function (event) {
    var that = this;
    var toggleBtnVal = that.data.uhide;
    var itemId = event.currentTarget.id;
    if (toggleBtnVal == itemId) {
      that.setData({
        uhide: 0
      })
    } else {
      that.setData({
        uhide: itemId
      })
    }
  },
  clickme:function(e){
    console.log("点击了我");
    this.setData({
      hello:"helloworld"
    })
    var _this=this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        _this.setData({
          tempFilePaths:res.tempFilePaths
        })
       
      }
    }); 
  },
  choosePos:function(e){
    var pos_this=this;
    wx.chooseLocation({
      success: function(res) {
        pos_this.setData({
          pos: res.name
        });
      },
    })
  },
  addData:function(){
    console.log("成功添加数据");
    console.log(uuid.v4());
    
    /////////添加一行数据
    var diary = new Diary();
    diary.set("title", uuid.v4());
    diary.set("content", "helloBmob");
    diary.set("author", "wx");
    //添加数据，第一个入口参数是null
    diary.save(null, {
      success: function (result) {
        //添加成功后，返回成功之后的ObjectId(返回的属性名是id,不是objectid)可以在Bmob的Web管理后台看到对应的数据
        console.log("日记创建成功，objectid:" + result.id);
      },
      error: function (result, error) {
        //添加失败
        console.log("创建日记失败");
      }
    });
    
  },
  imageInfo: function (e) {
    console.log('点击图片');
    var _this=this;
  }
}),
wx.onSocketOpen(function(res){
  console.log("WebSocket连接已打开");
});
const requestTask=wx.request({
  url: 'https://www.baidu.com',
  header:{
    'Content-Type':'application/json'
  },
  success:function(e){
    console.log('成功');
    console.log(e);

  },
  complete:function(){
    console.log('无论成功或者失败都会执行');
  }
});
requestTask.abort(function () {
  console.log('请求被终止');
});


/*
/////////添加一行数据
var diary=new Diary();
diary.set("title","wx");
diary.set("content","helloBmob");
diary.set("author","wx");
//添加数据，第一个入口参数是null
diary.save(null,{
  success:function(result){
    //添加成功后，返回成功之后的ObjectId(返回的属性名是id,不是objectid)可以在Bmob的Web管理后台看到对应的数据
    console.log("日记创建成功，objectid:"+result.id);
  },
  error:function(result,error){
    //添加失败
    console.log("创建日记失败");
  }
});
*/

/*
//////////////获取一行数据
var query = new Bmob.Query(Diary);
query.get("e299dd2695",{
  success:function(result){
    ///数据获取成功
    console.log("日记的title: "+result.get("title")+" content: "+result.get("content")+" author: "+result.get("author"));
  },
  error:function(result,error){
    console.log("查询失败");  
  }
})
*/

/*
///////修改一行数据
var query= new Bmob.Query(Diary);
query.get("0eeba85bc8",{
  success:function(result){
    //回调中对获取的这个查询对象的实例进行修改
    result.set("title","phone");
    result.set("content","lost");
    result.set("author","xiaoming");
    result.save();
    console.log("修改成功");
  },
  error:function(result,error){
    console.log("修改数据失败");
  }
});
*/

/*
/////////////////////删除一行数据
var query= new Bmob.Query(Diary);
query.get("e299dd2695",{
  success:function(object){
    object.destroy({
      success:function(deleteobject){
        console.log("成功删除该条数据");
      },
      error:function(deleteobject,error){
        console.log("删除数据失败");
      }
    })
  },
  error:function(object,error){
    console.log("获取数据失败");
  }
})
*/

/*
 //初始连接socket.io服务器后，需要监听的事件都写在这个函数内
BmobSocketIo.onInitListen=function(){
  //订阅diary表的数据更新事件
  BmobSocketIo.updateTable("diary");
};
//监听服务器返回的更新的表的数据
BmobSocketIo.onUpdateTable=function(tablename,data){
  if(tablename=="diary"){
    console.log(data);
  }
}
*/